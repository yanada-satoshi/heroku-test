# backlog2trello

Add a card to the trello board when backlog ticket's status is changed
Works with Hubot :-)
